<?php
/* 初始化引入 */
require_once "initialism.php";

/* 輸出 */
require_once "print_out_info.php";

/* 本檔案使用函數 */
$smarty->display('gallery.html');
