<?php
require_once('config.php');
require_once('funtion.php');

if (isset($_POST['user_name'])&&isset($_POST['user_password'])&&isset($_POST['user_identity'])) {
    echo "<div class='alert alert-success'>〔{$_POST['user_name']}，身分：{$_POST['user_identity']}〕您好!歡迎使用衛生分數管理系統~</div>";
}
