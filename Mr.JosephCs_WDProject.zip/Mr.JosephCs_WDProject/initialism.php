<?php
/* 初始化引入 */
session_start();
require_once "config.php";
require_once 'smarty/libs/Smarty.class.php';
//用戶及單位資訊
$smarty = new Smarty;
$owner = _OWNER;
$email = _DESIGNER_EMAIL;
$designer = _SYSTEM_DESIGNER;
$system_name = _SYSTEM_NAME;
