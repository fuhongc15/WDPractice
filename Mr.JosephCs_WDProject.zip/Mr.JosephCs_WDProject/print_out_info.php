<?php
/* 輸出 */
$smarty->assign('designer', $designer);
$smarty->assign('owner', $owner);
$smarty->assign('email', $email);
$smarty->assign('system_name', $system_name);
