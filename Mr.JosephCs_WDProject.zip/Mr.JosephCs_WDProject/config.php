<?php

//網站基本定義
define('_SYSTEM_NAME', 'Mr.JosephCs World');
define('_OWNER', '池富鴻');;
define('_DESIGNER_EMAIL', 'myjfc15@gmail.com');
define('_SYSTEM_DESIGNER', '佛光大學 資訊應用學系 池富鴻');

//錯誤訊息
define('_ERROR_INFO', '您輸入的資料有誤，請先檢查並再重新輸入一次');
